package ru.myitschool.lab22toast;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private final int duration = Toast.LENGTH_LONG;
    private static int rotate = 0;
    private static boolean isRotate = true;

    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        setContentView(R.layout.activity_main);
        if ((rotate % 2 != 0 || rotate == 0) && (isRotate))
            Toast.makeText(this, R.string.ncreate, duration).show();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if ((rotate % 2 != 0 || rotate == 0) && (isRotate))
            Toast.makeText(this, R.string.nstart, duration).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if ((rotate % 2 != 0 || rotate == 0) && (isRotate))
            Toast.makeText(this, R.string.nresume, duration).show();
        isRotate = false;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        rotate++;
        isRotate = true;
        if (rotate % 2 == 0)
            Toast.makeText(this, R.string.ndestroy, duration).show();
    }
}